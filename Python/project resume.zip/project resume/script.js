function downloadPDF() {

window.print();

}